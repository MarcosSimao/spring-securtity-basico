package com.app.seguranca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegurancaApplicationTests {

	@Test
	void contextLoads() {
	}

}
